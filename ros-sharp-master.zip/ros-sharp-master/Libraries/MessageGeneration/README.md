# [MessageGeneration](https://github.com/siemens/ros-sharp/tree/master/Libraries/MessageGeneration) #
[.NET](https://www.microsoft.com/net) Library for generating C# source code for [ROS](http://www.ros.org/) message/service/action.

__Please see the [Wiki](https://github.com/siemens/ros-sharp/wiki) page for [New Message Types](https://github.com/siemens/ros-sharp/wiki/Dev_NewMessageTypes) for further info.__

---

© Siemens AG, 2017-2024